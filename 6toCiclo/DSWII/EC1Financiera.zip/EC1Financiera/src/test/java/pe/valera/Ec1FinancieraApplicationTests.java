package pe.valera;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ec1FinancieraApplicationTests {

	@Test
	void contextLoads() {
	}

}
