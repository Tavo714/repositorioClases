package pe.negocio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestPersistentev1Application {

	public static void main(String[] args) {
		SpringApplication.run(RestPersistentev1Application.class, args);
	}

}
